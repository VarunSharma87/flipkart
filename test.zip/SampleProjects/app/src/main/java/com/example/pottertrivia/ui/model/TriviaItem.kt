package com.example.pottertrivia.ui.model

sealed class TriviaItem {
    data class Character(
        val birthdate: String,
        val children: List<String>,
        val fullName: String,
        val hogwartsHouse: String,
        val image: String,
        val interpretedBy: String,
        val nickname: String
    ) : TriviaItem()

    data class Book(
        val cover: String,
        val description: String,
        val number: Int,
        val originalTitle: String,
        val pages: Int,
        val releaseDate: String,
        val title: String
    ) : TriviaItem()

    data class House(
        val founder: String,
        val house: String,
    ) : TriviaItem()

    data class Spell(
        val spell: String,
        val use: String
    ) : TriviaItem()

    data class HeaderItem(val title: String) : TriviaItem()
}