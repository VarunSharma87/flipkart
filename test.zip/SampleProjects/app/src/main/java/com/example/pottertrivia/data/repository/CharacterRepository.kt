package com.example.pottertrivia.data.repository

import com.example.pottertrivia.domain.model.Character

interface CharacterRepository {

    suspend fun getCharacterDetails(fullName: String): Character

    suspend fun searchCharacters(
        searchText: String,
        networkAvailable: Boolean
    ): List<Character>
}