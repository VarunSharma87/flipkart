package com.example.pottertrivia.ui.fragments

import androidx.fragment.app.viewModels
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DividerItemDecoration
import com.example.pottertrivia.util.NetworkUtil
import com.example.pottertrivia.ui.model.TriviaItem
import com.example.pottertrivia.ui.adapter.TriviaListAdapter
import com.example.pottertrivia.ui.model.TriviaUiState
import com.example.pottertrivia.ui.viewmodel.SearchTriviaViewModel
import com.example.pottertriviaapp.R
import com.example.pottertriviaapp.databinding.FragmentSearchTriviaBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SearchTriviaFragment : Fragment() {

    private lateinit var binding: FragmentSearchTriviaBinding
    private val viewModel: SearchTriviaViewModel by viewModels()
    private var searchText: String? = null
    private var isViewSetup = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        if (::binding.isInitialized.not()) {
            binding = FragmentSearchTriviaBinding.inflate(inflater)
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setUpUI()
        isViewSetup = true
    }

    private fun setUpUI() {
        setUpSearchList()
        setTextChangedListener()
        if (isViewSetup.not()) {
            viewModel.getRandomSpell(NetworkUtil.isNetworkAvailable(context))
        }
    }

    private fun setUpSearchList() {
        val adapter = TriviaListAdapter()
        adapter.addOnItemClickListener {
            handleItemClick(it)
        }
        binding.triviaList.adapter = adapter
        binding.triviaList.addItemDecoration(
            DividerItemDecoration(
                context,
                DividerItemDecoration.VERTICAL
            )
        )
        adapter.submitList(null)

        viewModel.uiState.observe(viewLifecycleOwner) {
            handleUIStateChange(it)
        }
    }

    private fun handleUIStateChange(uiState: TriviaUiState) {
        if (uiState.searchResult.isNullOrEmpty() && searchText.isNullOrEmpty()) {
            binding.triviaList.visibility = View.GONE
            binding.spellName.text = uiState.randomSpell?.spell
            binding.spellDescription.text = uiState.randomSpell?.use
            binding.spellName.visibility = View.VISIBLE
            binding.spellDescription.visibility = View.VISIBLE
        } else {
            binding.spellName.visibility = View.GONE
            binding.spellDescription.visibility = View.GONE
            binding.triviaList.visibility = View.VISIBLE
            val localAdapter = binding.triviaList.adapter as TriviaListAdapter
            localAdapter.submitList(uiState.searchResult)
        }
    }

    private fun setTextChangedListener() {
        binding.searchView.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                s?.let {
                    searchText = s.toString()
                    if (it.length > 1) {
                        viewModel.searchTrivia(
                            s.toString(),
                            NetworkUtil.isNetworkAvailable(context)
                        )
                    } else {
                        viewModel.clearSearchResults()
                    }
                }
            }

            override fun afterTextChanged(s: Editable?) {
            }

        })
    }

    private fun handleItemClick(itemClicked: TriviaItem) {
        when (itemClicked) {
            is TriviaItem.Character -> {
                val fragment =
                    TriviaDetailFragment.newInstance(itemClicked.fullName, TriviaType.CHARACTER)
                replaceFragment(fragment)
            }

            is TriviaItem.Book -> {
                val fragment = TriviaDetailFragment.newInstance(itemClicked.title, TriviaType.BOOK)
                replaceFragment(fragment)
            }

            is TriviaItem.House -> {
                val fragment = TriviaDetailFragment.newInstance(itemClicked.house, TriviaType.HOUSE)
                replaceFragment(fragment)
            }

            is TriviaItem.Spell -> {
                val fragment = TriviaDetailFragment.newInstance(itemClicked.spell, TriviaType.SPELL)
                replaceFragment(fragment)
            }

            is TriviaItem.HeaderItem -> return
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        parentFragmentManager.beginTransaction().apply {
            replace(R.id.containerView, fragment)
            addToBackStack(null)
            commit()
        }
    }
}