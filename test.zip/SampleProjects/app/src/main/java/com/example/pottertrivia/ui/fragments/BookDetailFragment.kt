package com.example.pottertrivia.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.pottertrivia.ui.viewmodel.BookDetailViewModel
import com.example.pottertriviaapp.databinding.FramentBookDetailsBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BookDetailFragment : Fragment() {

    private var bookNumber = 0

    companion object {
        const val BOOK_NUMBER = "book-number"
        fun newInstance(bookNumber: Int) = SearchTriviaFragment().apply {
            arguments = Bundle().apply {
                putInt(BOOK_NUMBER, bookNumber)
            }
        }
    }

    private lateinit var binding: FramentBookDetailsBinding
    private val viewModel: BookDetailViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            bookNumber = it.getInt(BOOK_NUMBER)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding = FramentBookDetailsBinding.inflate(inflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.fetchBookDetails(bookNumber)
        viewModel.bookDetail.observe(viewLifecycleOwner) {
            binding.toolbar.title = it.title
        }
    }
}