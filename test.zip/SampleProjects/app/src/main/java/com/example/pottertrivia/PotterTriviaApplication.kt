package com.example.pottertrivia

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PotterTriviaApplication : Application()