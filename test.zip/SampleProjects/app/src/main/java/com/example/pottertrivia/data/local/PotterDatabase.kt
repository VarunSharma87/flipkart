package com.example.pottertrivia.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.pottertrivia.data.local.dao.BooksDao
import com.example.pottertrivia.data.local.dao.CharactersDao
import com.example.pottertrivia.data.local.dao.HousesDao
import com.example.pottertrivia.data.local.dao.SpellsDao
import com.example.pottertrivia.data.local.entity.BooksEntity
import com.example.pottertrivia.data.local.entity.CharactersEntity
import com.example.pottertrivia.data.local.entity.HousesEntity
import com.example.pottertrivia.data.local.entity.SpellsEntity

@Database(
    entities = [
        BooksEntity::class,
        CharactersEntity::class,
        HousesEntity::class,
        SpellsEntity::class
    ],
    version = 1
)
@TypeConverters(Converters::class)
abstract class PotterDatabase : RoomDatabase() {
    abstract fun booksDao(): BooksDao
    abstract fun charactersDao(): CharactersDao
    abstract fun housesDao(): HousesDao
    abstract fun spellsDao(): SpellsDao
}