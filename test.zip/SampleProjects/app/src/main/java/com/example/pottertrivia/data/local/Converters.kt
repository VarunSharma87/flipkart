package com.example.pottertrivia.data.local

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class Converters {

    @TypeConverter
    fun listToString(list: List<String>): String {
        return Gson().toJson(list)
    }

    @TypeConverter
    fun stringToList(list: String): List<String> {
        val listType = object : TypeToken<List<String>>() {}.type
        return Gson().fromJson(list, listType)
    }
}