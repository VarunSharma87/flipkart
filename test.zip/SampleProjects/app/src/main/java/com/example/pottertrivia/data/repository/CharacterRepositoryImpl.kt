package com.example.pottertrivia.data.repository

import com.example.pottertrivia.data.local.dao.CharactersDao
import com.example.pottertrivia.data.local.entity.toDomainModel
import com.example.pottertrivia.data.remote.TriviaRemoteSource
import com.example.pottertrivia.data.remote.model.toDomainModel
import com.example.pottertrivia.data.remote.model.toEntityModel
import com.example.pottertrivia.domain.model.Character
import javax.inject.Inject

class CharacterRepositoryImpl @Inject constructor(
    private val localSource: CharactersDao,
    private val remoteSource: TriviaRemoteSource
) : CharacterRepository {

    override suspend fun searchCharacters(
        searchText: String,
        networkAvailable: Boolean
    ): List<Character> {
        return if (networkAvailable) {
            val result = remoteSource.fetchCharacters(searchText)
            localSource.insertAll(result.map { it.toEntityModel() })
            result.map { it.toDomainModel() }
        } else {
            localSource.getMatchingCharacters(searchText).map { it.toDomainModel() }
        }
    }

    override suspend fun getCharacterDetails(fullName: String): Character {
        return localSource.getCharacterDetails(fullName).toDomainModel()
    }
}