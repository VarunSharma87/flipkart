package com.example.pottertrivia.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.pottertrivia.data.local.entity.BooksEntity
import com.example.pottertrivia.data.local.entity.CharactersEntity

@Dao
interface BooksDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(characters: List<BooksEntity>)

    @Query("Select * from books where title LIKE '%' || :searchQuery || '%'")
    suspend fun getMatchingBooks(searchQuery: String): List<BooksEntity>

    @Query("Select * from books where number=:id")
    suspend fun getBookById(id: Int): BooksEntity
}