package com.example.pottertrivia.data.remote.api

import com.example.pottertrivia.data.remote.model.BooksDto
import com.example.pottertrivia.data.remote.model.CharacterDto
import com.example.pottertrivia.data.remote.model.HouseDto
import com.example.pottertrivia.data.remote.model.SpellDto
import retrofit2.http.GET
import retrofit2.http.Query

interface PotterRemoteApi {

    @GET("en/spells")
    suspend fun fetchSpells(
        @Query("search") searchText: String
    ): List<SpellDto>

    @GET("en/books")
    suspend fun fetchBooks(@Query("search") searchText: String): List<BooksDto>

    @GET("en/characters")
    suspend fun fetchCharacters(@Query("search") searchText: String): List<CharacterDto>

    @GET("en/houses")
    suspend fun fetchHouses(@Query("search") searchText: String): List<HouseDto>
}