package com.example.pottertrivia.domain.model

data class Spell(
    val index: Int,
    val spell: String,
    val use: String
)
