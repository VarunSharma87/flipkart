package com.example.pottertrivia.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.bumptech.glide.Glide
import com.example.pottertrivia.ui.model.TriviaDetail
import com.example.pottertrivia.ui.viewmodel.TriviaDetailViewModel
import com.example.pottertriviaapp.R
import com.example.pottertriviaapp.databinding.FragmentTriviaDetailBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TriviaDetailFragment : Fragment() {

    private var triviaIdentifier: String? = null
    private var triviaType: TriviaType? = null

    companion object {
        const val TRIVIA_TYPE = "trivia-type"
        const val TRIVIA_IDENTIFIER = "book-number"
        fun newInstance(triviaIdentifier: String, triviaType: TriviaType) =
            TriviaDetailFragment().apply {
                arguments = Bundle().apply {
                    putString(TRIVIA_IDENTIFIER, triviaIdentifier)
                    putString(TRIVIA_TYPE, triviaType.name)
                }
            }
    }

    private lateinit var binding: FragmentTriviaDetailBinding
    private val viewModel: TriviaDetailViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            triviaIdentifier = it.getString(TRIVIA_IDENTIFIER)
            triviaType = it.getString(TRIVIA_TYPE)?.let { it1 -> TriviaType.valueOf(it1) }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding = FragmentTriviaDetailBinding.inflate(inflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (triviaIdentifier.isNullOrEmpty() || triviaType == null) handleBackButtonClick()
        setupUI()
        fetchTriviaDetails()
    }

    private fun setupUI() {
        binding.toolbar.setNavigationIcon(R.drawable.ic_back)
        binding.toolbar.setNavigationOnClickListener {
            handleBackButtonClick()
        }
        viewModel.triviaDetail.observe(viewLifecycleOwner) { uiState ->
            updateUI(uiState.triviaDetail)
        }
    }

    private fun updateUI(bookDetail: TriviaDetail?) {
        bookDetail?.let {
            binding.toolbar.title = it.titleBarText
            it.cover?.let { cover ->
                Glide.with(this).load(cover).centerInside().into(binding.coverImage)
            } ?: run {
                binding.coverImage.visibility = View.GONE
            }
            binding.title.text = it.title
            binding.descriptionText.text = it.description
        }
    }

    private fun handleBackButtonClick() {
        requireActivity().onBackPressedDispatcher.onBackPressed()
    }

    private fun fetchTriviaDetails() {
        triviaIdentifier?.let {
            when (triviaType) {
                TriviaType.BOOK -> viewModel.fetchBookDetails(it)
                TriviaType.SPELL -> viewModel.fetchSpellDetails(it)
                TriviaType.CHARACTER -> viewModel.fetchCharacterDetails(it)
                TriviaType.HOUSE -> viewModel.fetchHouseDetails(it)
                null -> {
                    print("Invalid trivia type")
                }
            }
        }

    }
}

enum class TriviaType {
    BOOK, SPELL, CHARACTER, HOUSE
}