package com.example.pottertrivia.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.pottertrivia.data.local.entity.CharactersEntity
import com.example.pottertrivia.data.local.entity.SpellsEntity

@Dao
interface SpellsDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(vararg characters: SpellsEntity)

    @Query("Select * from spells where spell LIKE '%' || :searchQuery || '%'")
    suspend fun getMatchingSpells(searchQuery: String): List<SpellsEntity>

    @Query("Select * from spells where spell =:spell")
    suspend fun getSpellDetails(spell: String): SpellsEntity

    @Query("Select * from spells order by RANDOM() LIMIT 1")
    suspend fun getRandomSpell(): SpellsEntity
}