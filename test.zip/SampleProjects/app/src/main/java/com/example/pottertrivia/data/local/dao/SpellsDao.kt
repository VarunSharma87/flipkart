package com.example.pottertrivia.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.pottertrivia.data.local.entity.CharactersEntity
import com.example.pottertrivia.data.local.entity.SpellsEntity

@Dao
interface SpellsDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(characters: List<SpellsEntity>)

    @Query("Select * from spells where spell LIKE '%' || :searchQuery || '%'")
    suspend fun getMatchingSpells(searchQuery: String): List<SpellsEntity>
}