package com.example.pottertrivia.domain.usecase

interface TriviaSearchUseCase {
    suspend fun invoke(
        searchQuery: String,
        networkAvailable: Boolean
    ): SearchResult
}