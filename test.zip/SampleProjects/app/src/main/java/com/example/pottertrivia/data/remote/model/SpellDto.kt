package com.example.pottertrivia.data.remote.model

import com.example.pottertrivia.data.local.entity.SpellsEntity
import com.example.pottertrivia.domain.model.TriviaSearchResult

data class SpellDto(
    val index: Int,
    val spell: String,
    val use: String
)

fun SpellDto.toEntityModel() = SpellsEntity(index, spell, use)

fun SpellDto.toDomainModel() = TriviaSearchResult.Spell(index, spell, use)