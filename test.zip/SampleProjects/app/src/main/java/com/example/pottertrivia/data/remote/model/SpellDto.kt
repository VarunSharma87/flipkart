package com.example.pottertrivia.data.remote.model

import com.example.pottertrivia.data.local.entity.SpellsEntity
import com.example.pottertrivia.domain.model.Spell

data class SpellDto(
    val index: Int,
    val spell: String,
    val use: String
)

fun SpellDto.toEntityModel() = SpellsEntity(spell, index, use)

fun SpellDto.toDomainModel() = Spell(index, spell, use)