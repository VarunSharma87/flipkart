package com.example.pottertrivia.data.repository

import com.example.pottertrivia.data.local.dao.BooksDao
import com.example.pottertrivia.data.local.entity.toDomainModel
import com.example.pottertrivia.data.remote.TriviaRemoteSourceImpl
import com.example.pottertrivia.data.remote.model.toDomainModel
import com.example.pottertrivia.data.remote.model.toEntityModel
import com.example.pottertrivia.domain.model.Book
import javax.inject.Inject

class BooksRepositoryImpl @Inject constructor(
    private val booksDao: BooksDao,
    private val remoteSource: TriviaRemoteSourceImpl,
) : BookRepository {

    override suspend fun getBooks(
        searchQuery: String,
        isNetworkAvailable: Boolean
    ): List<Book> {
        return if (isNetworkAvailable) {
            val result = remoteSource.fetchBooks(searchQuery)
            booksDao.insertAll(result.map { it.toEntityModel() })
            result.map { it.toDomainModel() }
        } else {
            booksDao.getMatchingBooks(searchQuery).map { it.toDomainModel() }
        }
    }

    override suspend fun getBookDetails(title: String): Book {
        return booksDao.getBookByTitle(title).toDomainModel()
    }
}