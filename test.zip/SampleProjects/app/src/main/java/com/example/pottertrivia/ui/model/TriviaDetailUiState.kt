package com.example.pottertrivia.ui.model

data class TriviaDetailUiState(val triviaDetail: TriviaDetail? = null, val error: String? = null)

data class TriviaDetail(
    val titleBarText: String,
    val title: String,
    val cover: String? = null,
    val description: String
)
