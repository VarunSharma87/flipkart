package com.example.pottertrivia.ui.viewholder

import android.graphics.Color
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import androidx.viewbinding.ViewBinding
import com.example.pottertrivia.ui.model.TriviaItem
import com.example.pottertriviaapp.databinding.HeaderListItemBinding
import com.example.pottertriviaapp.databinding.TriviaListItemBinding

sealed class TriviaSearchViewHolder(
    binding: ViewBinding
) :
    ViewHolder(binding.root) {
    abstract fun bind(searchResult: TriviaItem, clickListener: ((TriviaItem) -> Unit)? = null)

    class HeaderViewHolder(
        private val binding: HeaderListItemBinding
    ) :
        TriviaSearchViewHolder(binding) {
        override fun bind(searchResult: TriviaItem, clickListener: ((TriviaItem) -> Unit)?) {
            searchResult as TriviaItem.HeaderItem
            binding.headerText.text = searchResult.title
        }
    }

    class TriviaListViewHolder(
        private val binding: TriviaListItemBinding
    ) :
        TriviaSearchViewHolder(binding) {
        override fun bind(searchResult: TriviaItem, clickListener: ((TriviaItem) -> Unit)?) {
            when (searchResult) {
                is TriviaItem.Character -> binding.triviaText.text = searchResult.fullName
                is TriviaItem.Book -> binding.triviaText.text = searchResult.title
                is TriviaItem.House -> binding.triviaText.text = searchResult.house
                is TriviaItem.Spell -> binding.triviaText.text = searchResult.spell
                else -> return
            }
            binding.parentItem.setOnClickListener {
                clickListener?.invoke(searchResult)
            }
        }
    }

}