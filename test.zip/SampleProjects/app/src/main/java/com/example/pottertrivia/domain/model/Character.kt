package com.example.pottertrivia.domain.model

data class Character(
    val birthdate: String,
    val children: List<String>,
    val fullName: String,
    val hogwartsHouse: String,
    val image: String,
    val index: Int,
    val interpretedBy: String,
    val nickname: String
)
