package com.example.pottertrivia.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.pottertrivia.data.local.entity.CharactersEntity
import com.example.pottertrivia.data.remote.model.CharacterDto

@Dao
interface CharactersDao {

    @Query("Select * from characters where fullName LIKE '%' || :searchQuery || '%'")
    suspend fun getMatchingCharacters(searchQuery: String): List<CharactersEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(characters: List<CharactersEntity>)

}