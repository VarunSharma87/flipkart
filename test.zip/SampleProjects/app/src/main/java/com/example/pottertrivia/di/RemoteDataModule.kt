package com.example.pottertrivia.di

import com.example.pottertrivia.data.remote.TriviaRemoteSource
import com.example.pottertrivia.data.remote.TriviaRemoteSourceImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
interface RemoteDataModule {

    @Binds
    fun bindTriviaRemoteSource(remoteSource: TriviaRemoteSourceImpl): TriviaRemoteSource

}