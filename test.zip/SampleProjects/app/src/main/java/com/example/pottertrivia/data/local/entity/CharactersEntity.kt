package com.example.pottertrivia.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.pottertrivia.domain.model.Character

@Entity(tableName = "characters")
data class CharactersEntity(
    @PrimaryKey
    @ColumnInfo("index")
    val index: Int,
    @ColumnInfo("birthdate")
    val birthdate: String,
    @ColumnInfo("children")
    val children: List<String>,
    @ColumnInfo("fullName")
    val fullName: String,
    @ColumnInfo("hogwartsHouse")
    val hogwartsHouse: String,
    @ColumnInfo("image")
    val image: String,
    @ColumnInfo("interpretedBy")
    val interpretedBy: String,
    @ColumnInfo("nickname")
    val nickname: String
)

fun CharactersEntity.toDomainModel() = Character(
    birthdate,
    children,
    fullName,
    hogwartsHouse,
    image,
    index,
    interpretedBy,
    nickname
)