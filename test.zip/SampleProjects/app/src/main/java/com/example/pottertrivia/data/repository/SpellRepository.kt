package com.example.pottertrivia.data.repository

import com.example.pottertrivia.domain.model.Spell

interface SpellRepository {

    suspend fun getSpells(
        searchQuery: String,
        networkAvailable: Boolean
    ): List<Spell>

    suspend fun getSpellDetails(spell: String): Spell

    suspend fun getRandomSpell(networkAvailable: Boolean): Spell

}