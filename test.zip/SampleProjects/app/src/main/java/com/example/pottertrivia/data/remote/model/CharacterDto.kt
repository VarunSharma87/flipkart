package com.example.pottertrivia.data.remote.model

import com.example.pottertrivia.data.local.entity.CharactersEntity
import com.example.pottertrivia.domain.model.TriviaSearchResult

data class CharacterDto(
    val birthdate: String,
    val children: List<String>,
    val fullName: String,
    val hogwartsHouse: String,
    val image: String,
    val index: Int,
    val interpretedBy: String,
    val nickname: String
)

fun CharacterDto.toDomainModel() = TriviaSearchResult.Character(
    birthdate,
    children,
    fullName,
    hogwartsHouse,
    image,
    index,
    interpretedBy,
    nickname
)

fun CharacterDto.toEntityModel() = CharactersEntity(
    index,
    birthdate,
    children,
    fullName,
    hogwartsHouse,
    image,
    interpretedBy,
    nickname
)