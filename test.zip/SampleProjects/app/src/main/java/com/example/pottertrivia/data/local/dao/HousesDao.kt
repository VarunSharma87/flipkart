package com.example.pottertrivia.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.pottertrivia.data.local.entity.BooksEntity
import com.example.pottertrivia.data.local.entity.CharactersEntity
import com.example.pottertrivia.data.local.entity.HousesEntity

@Dao
interface HousesDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(characters: List<HousesEntity>)

    @Query("Select * from houses where house LIKE '%' || :searchQuery || '%'")
    suspend fun getMatchingHouses(searchQuery: String): List<HousesEntity>
}