package com.example.pottertrivia.data.repository

import com.example.pottertrivia.data.local.dao.BooksDao
import com.example.pottertrivia.data.local.dao.CharactersDao
import com.example.pottertrivia.data.local.dao.HousesDao
import com.example.pottertrivia.data.local.dao.SpellsDao
import com.example.pottertrivia.data.local.entity.toDomainModel
import com.example.pottertrivia.data.remote.TriviaRemoteSource
import com.example.pottertrivia.data.remote.model.toDomainModel
import com.example.pottertrivia.data.remote.model.toEntityModel
import com.example.pottertrivia.domain.model.TriviaSearchResult
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import javax.inject.Inject

class TriviaRepository @Inject constructor(
    private val charactersDao: CharactersDao,
    private val booksDao: BooksDao,
    private val housesDao: HousesDao,
    private val spellsDao: SpellsDao,
    private val remoteSource: TriviaRemoteSource,
) {

    suspend fun searchResults(
        searchQuery: String,
        isNetworkAvailable: Boolean
    ): List<TriviaSearchResult> = coroutineScope {
        if (isNetworkAvailable) {
            val characters = async { remoteSource.fetchCharacters(searchQuery) }
            val books = async { remoteSource.fetchBooks(searchQuery) }
            val houses = async { remoteSource.fetchHouses(searchQuery) }
            val spells = async { remoteSource.fetchSpells(searchQuery) }
            val characterResult = characters.await().map { it.toDomainModel() }
            val bookResult = books.await().map { it.toDomainModel() }
            val houseResult = houses.await().map { it.toDomainModel() }
            val spellResult = spells.await().map { it.toDomainModel() }
            val result = addHeaders(characterResult, bookResult, spellResult, houseResult)
            charactersDao.insertAll(characters.await().map { it.toEntityModel() })
            booksDao.insertAll(books.await().map { it.toEntityModel() })
            housesDao.insertAll(houses.await().map { it.toEntityModel() })
            spellsDao.insertAll(spells.await().map { it.toEntityModel() })
            result
        } else {
            val characters = async {
                charactersDao.getMatchingCharacters(searchQuery).map { it.toDomainModel() }
            }
            val books =
                async { booksDao.getMatchingBooks(searchQuery).map { it.toDomainModel() } }
            val houses =
                async { housesDao.getMatchingHouses(searchQuery).map { it.toDomainModel() } }
            val spells =
                async { spellsDao.getMatchingSpells(searchQuery).map { it.toDomainModel() } }

            addHeaders(characters.await(), books.await(), spells.await(), houses.await())
        }
    }

    private fun addHeaders(
        characterResult: List<TriviaSearchResult.Character>,
        bookResult: List<TriviaSearchResult.Book>,
        spellResult: List<TriviaSearchResult.Spell>,
        houseResult: List<TriviaSearchResult.House>
    ): MutableList<TriviaSearchResult> {
        val result = mutableListOf<TriviaSearchResult>()
        if (characterResult.isNotEmpty()) {
            result.add(TriviaSearchResult.Header("Characters"))
            result.addAll(characterResult)
        }
        if (bookResult.isNotEmpty()) {
            result.add(TriviaSearchResult.Header("Books"))
            result.addAll(bookResult)
        }
        if (houseResult.isNotEmpty()) {
            result.add(TriviaSearchResult.Header("House"))
            result.addAll(houseResult)
        }
        if (spellResult.isNotEmpty()) {
            result.add(TriviaSearchResult.Header("Spells"))
            result.addAll(spellResult)
        }
        return result
    }

    suspend fun getBook(number: Int): TriviaSearchResult.Book {
        return booksDao.getBookById(number).toDomainModel()
    }
}