package com.example.pottertrivia.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.example.pottertrivia.domain.model.TriviaSearchResult
import com.example.pottertrivia.ui.viewholder.TriviaSearchResultViewHolder
import com.example.pottertriviaapp.databinding.TriviaListItemBinding

class TriviaListAdapter : ListAdapter<TriviaSearchResult, TriviaSearchResultViewHolder>(
    DiffCallback
) {
    private var clickListener: ((TriviaSearchResult) -> Unit)? = null
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): TriviaSearchResultViewHolder {
        val binding = TriviaListItemBinding.inflate(LayoutInflater.from(parent.context))
        return TriviaSearchResultViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TriviaSearchResultViewHolder, position: Int) {
        holder.bind(getItem(position), clickListener)
    }

    object DiffCallback : DiffUtil.ItemCallback<TriviaSearchResult>() {
        override fun areItemsTheSame(
            oldItem: TriviaSearchResult,
            newItem: TriviaSearchResult
        ): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(
            oldItem: TriviaSearchResult,
            newItem: TriviaSearchResult
        ): Boolean {
            return when (oldItem) {
                is TriviaSearchResult.Character -> {
                    newItem as TriviaSearchResult.Character
                    newItem.image == oldItem.image && newItem.fullName == oldItem.fullName
                }

                is TriviaSearchResult.Book -> {
                    newItem as TriviaSearchResult.Book
                    newItem.title == oldItem.title && newItem.cover == oldItem.cover
                }

                is TriviaSearchResult.House -> {
                    newItem as TriviaSearchResult.House
                    newItem.house == oldItem.house && newItem.founder == oldItem.founder
                }

                is TriviaSearchResult.Spell -> {
                    newItem as TriviaSearchResult.Spell
                    newItem.spell == oldItem.spell
                }

                is TriviaSearchResult.Header -> {
                    newItem as TriviaSearchResult.Header
                    newItem.title == oldItem.title
                }
            }
        }
    }

    fun addOnItemClickListener(listener: (TriviaSearchResult)-> Unit) {
        clickListener = listener
    }
}