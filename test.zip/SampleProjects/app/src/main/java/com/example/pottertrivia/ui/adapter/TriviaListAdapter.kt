package com.example.pottertrivia.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.example.pottertrivia.ui.model.TriviaItem
import com.example.pottertrivia.ui.viewholder.TriviaSearchViewHolder
import com.example.pottertriviaapp.databinding.HeaderListItemBinding
import com.example.pottertriviaapp.databinding.TriviaListItemBinding

class TriviaListAdapter : ListAdapter<TriviaItem, TriviaSearchViewHolder>(
    DiffCallback
) {
    private var clickListener: ((TriviaItem) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TriviaSearchViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            ViewType.Header.ordinal -> {
                val binding = HeaderListItemBinding.inflate(inflater, parent, false)
                TriviaSearchViewHolder.HeaderViewHolder(binding)
            }

            ViewType.Trivia.ordinal -> {
                val binding = TriviaListItemBinding.inflate(inflater, parent, false)
                TriviaSearchViewHolder.TriviaListViewHolder(binding)
            }

            else -> throw IllegalArgumentException("Invalid view type")
        }
    }


    override fun onBindViewHolder(holder: TriviaSearchViewHolder, position: Int) {
        holder.bind(getItem(position), clickListener)
    }

    override fun getItemViewType(position: Int): Int {
        return when (currentList[position]) {
            is TriviaItem.HeaderItem -> ViewType.Header.ordinal
            else -> ViewType.Trivia.ordinal
        }
    }


    object DiffCallback : DiffUtil.ItemCallback<TriviaItem>() {
        override fun areItemsTheSame(
            oldItem: TriviaItem,
            newItem: TriviaItem
        ): Boolean {
            if (oldItem::class != newItem::class) return false
            return when (oldItem) {
                is TriviaItem.Character -> {
                    newItem as TriviaItem.Character
                    newItem.fullName == oldItem.fullName
                }

                is TriviaItem.Book -> {
                    newItem as TriviaItem.Book
                    newItem.title == oldItem.title
                }

                is TriviaItem.House -> {
                    newItem as TriviaItem.House
                    newItem.house == oldItem.house
                }

                is TriviaItem.Spell -> {
                    newItem as TriviaItem.Spell
                    newItem.spell == oldItem.spell
                }

                is TriviaItem.HeaderItem -> {
                    newItem as TriviaItem.HeaderItem
                    newItem.title == oldItem.title
                }
            }
        }

        override fun areContentsTheSame(
            oldItem: TriviaItem,
            newItem: TriviaItem
        ): Boolean {
            return oldItem == newItem
        }
    }

    fun addOnItemClickListener(listener: (TriviaItem) -> Unit) {
        clickListener = listener
    }
}

enum class ViewType {
    Header,
    Trivia
}