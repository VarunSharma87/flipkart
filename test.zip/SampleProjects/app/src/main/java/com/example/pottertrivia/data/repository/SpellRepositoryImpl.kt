package com.example.pottertrivia.data.repository

import com.example.pottertrivia.data.local.dao.SpellsDao
import com.example.pottertrivia.data.local.entity.toDomainModel
import com.example.pottertrivia.data.remote.TriviaRemoteSource
import com.example.pottertrivia.data.remote.model.toDomainModel
import com.example.pottertrivia.data.remote.model.toEntityModel
import com.example.pottertrivia.domain.model.Spell
import javax.inject.Inject

class SpellRepositoryImpl @Inject constructor(
    private val localSource: SpellsDao,
    private val remoteSource: TriviaRemoteSource
) : SpellRepository {
    override suspend fun getSpells(
        searchQuery: String,
        networkAvailable: Boolean
    ): List<Spell> {
        return if (networkAvailable) {
            val result = remoteSource.fetchSpells(searchQuery)
            localSource.insertAll(*result.map { it.toEntityModel() }.toTypedArray())
            result.map { it.toDomainModel() }
        } else {
            localSource.getMatchingSpells(searchQuery).map { it.toDomainModel() }
        }
    }

    override suspend fun getSpellDetails(spell: String): Spell {
        return localSource.getSpellDetails(spell).toDomainModel()
    }

    override suspend fun getRandomSpell(networkAvailable: Boolean): Spell {
        return if (networkAvailable) {
            val result = remoteSource.fetchRandomSpell()
            localSource.insertAll(result.toEntityModel())
            result.toDomainModel()
        } else {
            localSource.getRandomSpell().toDomainModel()
        }
    }


}