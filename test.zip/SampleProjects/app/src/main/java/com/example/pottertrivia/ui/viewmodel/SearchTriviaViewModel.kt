package com.example.pottertrivia.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pottertrivia.data.repository.TriviaRepository
import com.example.pottertrivia.ui.model.TriviaUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SearchTriviaViewModel @Inject constructor() : ViewModel() {

    @Inject
    lateinit var repository: TriviaRepository

    private val _uiState = MutableLiveData<TriviaUiState>()
    val uiState: LiveData<TriviaUiState> = _uiState

    fun searchTrivia(searchText: String, isNetworkAvailable: Boolean) {
        viewModelScope.launch {
            val result = repository.searchResults(searchText, isNetworkAvailable)
            _uiState.value = TriviaUiState(result)
        }

    }
}