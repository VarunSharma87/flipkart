package com.example.pottertrivia.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.distinctUntilChanged
import androidx.lifecycle.viewModelScope
import com.example.pottertrivia.data.repository.SpellRepository
import com.example.pottertrivia.domain.usecase.SearchResult
import com.example.pottertrivia.domain.usecase.TriviaSearchUseCase
import com.example.pottertrivia.ui.model.TriviaItem
import com.example.pottertrivia.ui.model.TriviaUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class SearchTriviaViewModel @Inject constructor() : ViewModel() {

    @Inject
    lateinit var searchUseCase: TriviaSearchUseCase

    @Inject
    lateinit var spellRepository: SpellRepository

    private var currentSearchText: String? = null
    private val _uiState = MutableLiveData<TriviaUiState>()
    val uiState: LiveData<TriviaUiState> = _uiState

    fun getRandomSpell(isNetworkAvailable: Boolean) {
        viewModelScope.launch {
            val result = spellRepository.getRandomSpell(isNetworkAvailable)
            _uiState.value = TriviaUiState(result, null)
        }
    }

    fun searchTrivia(
        searchText: String,
        isNetworkAvailable: Boolean,
        dispatcher: CoroutineDispatcher = Dispatchers.IO
    ) {
        if (currentSearchText == searchText) return
        currentSearchText = searchText
        viewModelScope.launch {
            val result = searchUseCase.invoke(searchText, isNetworkAvailable)
            _uiState.value = addHeadersToResult(result, dispatcher)
        }
    }

    private suspend fun addHeadersToResult(
        searchResult: SearchResult,
        coroutineDispatcher: CoroutineDispatcher
    ): TriviaUiState {
        return withContext(coroutineDispatcher) {
            val mergedOutput = mutableListOf<TriviaItem>()
            if (searchResult.houses.isNotEmpty()) {
                mergedOutput.add(TriviaItem.HeaderItem("House"))
                mergedOutput.addAll(searchResult.houses.map {
                    TriviaItem.House(
                        it.founder,
                        it.house,
                    )
                })
            }
            if (searchResult.spells.isNotEmpty()) {
                mergedOutput.add(TriviaItem.HeaderItem("Spells"))
                mergedOutput.addAll(searchResult.spells.map {
                    TriviaItem.Spell(
                        it.spell,
                        it.use
                    )
                })
            }
            if (searchResult.characters.isNotEmpty()) {
                mergedOutput.add(TriviaItem.HeaderItem("Characters"))
                mergedOutput.addAll(searchResult.characters.map {
                    TriviaItem.Character(
                        it.birthdate,
                        it.children,
                        it.fullName,
                        it.hogwartsHouse,
                        it.image,
                        it.interpretedBy,
                        it.nickname
                    )
                })
            }
            if (searchResult.books.isNotEmpty()) {
                mergedOutput.add(TriviaItem.HeaderItem("Books"))
                mergedOutput.addAll(searchResult.books.map {
                    TriviaItem.Book(
                        it.cover,
                        it.description,
                        it.number,
                        it.originalTitle,
                        it.pages,
                        it.releaseDate,
                        it.title
                    )
                })
            }
            val currentUiState = _uiState.value
            currentUiState?.copy(searchResult = mergedOutput) ?: TriviaUiState(null, null)
        }
    }

    fun clearSearchResults() {
        val uiState = _uiState.value?.copy(searchResult = null) ?: TriviaUiState(null, null)
        _uiState.value = uiState
    }
}