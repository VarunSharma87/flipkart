package com.example.pottertrivia.domain.usecase

import com.example.pottertrivia.data.repository.BookRepository
import com.example.pottertrivia.data.repository.CharacterRepository
import com.example.pottertrivia.data.repository.HouseRepository
import com.example.pottertrivia.data.repository.SpellRepository
import com.example.pottertrivia.domain.model.Book
import com.example.pottertrivia.domain.model.Character
import com.example.pottertrivia.domain.model.House
import com.example.pottertrivia.domain.model.Spell
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import javax.inject.Inject

class TriviaSearchUseCaseImpl @Inject constructor(
    private val characterRepository: CharacterRepository,
    private val booksRepository: BookRepository,
    private val houseRepository: HouseRepository,
    private val spellRepository: SpellRepository
) : TriviaSearchUseCase {

    override suspend fun invoke(
        searchQuery: String,
        networkAvailable: Boolean
    ): SearchResult = coroutineScope {
        val characters =
            async { characterRepository.searchCharacters(searchQuery, networkAvailable) }
        val books = async { booksRepository.getBooks(searchQuery, networkAvailable) }
        val houses = async { houseRepository.getHouses(searchQuery, networkAvailable) }
        val spells = async { spellRepository.getSpells(searchQuery, networkAvailable) }
        SearchResult(characters.await(), spells.await(), books.await(), houses.await())
    }
}

data class SearchResult(
    val characters: List<Character>,
    val spells: List<Spell>,
    val books: List<Book>,
    val houses: List<House>
)