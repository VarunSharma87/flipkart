package com.example.pottertrivia.data.remote.model

data class Source(
    val id: String,
    val name: String
)