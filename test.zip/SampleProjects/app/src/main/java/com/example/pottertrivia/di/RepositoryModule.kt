package com.example.pottertrivia.di

import com.example.pottertrivia.data.repository.BookRepository
import com.example.pottertrivia.data.repository.BooksRepositoryImpl
import com.example.pottertrivia.data.repository.CharacterRepository
import com.example.pottertrivia.data.repository.CharacterRepositoryImpl
import com.example.pottertrivia.data.repository.HouseRepository
import com.example.pottertrivia.data.repository.HouseRepositoryImpl
import com.example.pottertrivia.data.repository.SpellRepository
import com.example.pottertrivia.data.repository.SpellRepositoryImpl
import com.example.pottertrivia.domain.usecase.TriviaSearchUseCase
import com.example.pottertrivia.domain.usecase.TriviaSearchUseCaseImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityRetainedComponent

@Module
@InstallIn(ActivityRetainedComponent::class)
abstract class RepositoryModule {

    @Binds
    abstract fun bindBookRepository(bookRepository: BooksRepositoryImpl): BookRepository

    @Binds
    abstract fun bindTriviaSearchUseCase(triviaRepository: TriviaSearchUseCaseImpl): TriviaSearchUseCase

    @Binds
    abstract fun bindHouseRepository(houseRepository: HouseRepositoryImpl): HouseRepository

    @Binds
    abstract fun bindSpellRepository(spellRepository: SpellRepositoryImpl): SpellRepository

    @Binds
    abstract fun bindCharacterRepository(triviaRepository: CharacterRepositoryImpl): CharacterRepository

}