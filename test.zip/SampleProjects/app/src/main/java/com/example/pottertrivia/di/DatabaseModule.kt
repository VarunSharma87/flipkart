package com.example.pottertrivia.di

import android.content.Context
import androidx.room.Room
import com.example.pottertrivia.data.local.PotterDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    fun providesNewsDatabase(@ApplicationContext context: Context): PotterDatabase {
        return Room.databaseBuilder(context, PotterDatabase::class.java, "news_database").build()
    }

}