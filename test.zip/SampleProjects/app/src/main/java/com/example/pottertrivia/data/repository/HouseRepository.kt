package com.example.pottertrivia.data.repository

import com.example.pottertrivia.domain.model.House

interface HouseRepository {
    suspend fun getHouses(
        searchQuery: String,
        networkAvailable: Boolean
    ): List<House>

    suspend fun getHouseDetails(
        house: String
    ): House
}