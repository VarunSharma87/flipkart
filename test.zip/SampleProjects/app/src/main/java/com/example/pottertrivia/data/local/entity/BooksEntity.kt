package com.example.pottertrivia.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.pottertrivia.domain.model.TriviaSearchResult

@Entity("books")
data class BooksEntity(
    @PrimaryKey
    @ColumnInfo("number")
    val number: Int,
    @ColumnInfo("cover")
    val cover: String,
    @ColumnInfo("description")
    val description: String,
    @ColumnInfo("index")
    val index: Int,
    @ColumnInfo("originalTitle")
    val originalTitle: String,
    @ColumnInfo("pages")
    val pages: Int,
    @ColumnInfo("releaseDate")
    val releaseDate: String,
    @ColumnInfo("title")
    val title: String
)

fun BooksEntity.toDomainModel() = TriviaSearchResult.Book(cover, description, index, number, originalTitle, pages, releaseDate, title)