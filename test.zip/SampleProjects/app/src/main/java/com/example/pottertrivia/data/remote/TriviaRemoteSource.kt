package com.example.pottertrivia.data.remote

import com.example.pottertrivia.data.local.entity.CharactersEntity
import com.example.pottertrivia.data.remote.model.BooksDto
import com.example.pottertrivia.data.remote.model.CharacterDto
import com.example.pottertrivia.data.remote.model.HouseDto
import com.example.pottertrivia.data.remote.model.SpellDto

interface TriviaRemoteSource {
    suspend fun fetchCharacters(searchText: String): List<CharacterDto>

    suspend fun fetchBooks(searchText: String): List<BooksDto>

    suspend fun fetchHouses(searchText: String): List<HouseDto>

    suspend fun fetchSpells(searchText: String): List<SpellDto>

    suspend fun fetchRandomSpell(): SpellDto
}