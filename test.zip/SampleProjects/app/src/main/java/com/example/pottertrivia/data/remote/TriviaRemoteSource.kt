package com.example.pottertrivia.data.remote

import com.example.pottertrivia.data.remote.api.PotterRemoteApi
import com.example.pottertrivia.data.remote.model.BooksDto
import com.example.pottertrivia.data.remote.model.CharacterDto
import com.example.pottertrivia.data.remote.model.HouseDto
import com.example.pottertrivia.data.remote.model.SpellDto
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Inject

class TriviaRemoteSource @Inject constructor() {
    private val networkApi = Retrofit.Builder()
        .baseUrl(TRIVIA_BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(PotterRemoteApi::class.java)

    suspend fun fetchCharacters(searchText: String): List<CharacterDto> =
        networkApi.fetchCharacters(searchText)

    suspend fun fetchBooks(searchText: String): List<BooksDto> =
        networkApi.fetchBooks(searchText)

    suspend fun fetchHouses(searchText: String): List<HouseDto> =
        networkApi.fetchHouses(searchText)

    suspend fun fetchSpells(searchText: String): List<SpellDto> =
        networkApi.fetchSpells(searchText)

    companion object {
        const val TRIVIA_BASE_URL = "https://potterapi-fedeperin.vercel.app "
    }
}