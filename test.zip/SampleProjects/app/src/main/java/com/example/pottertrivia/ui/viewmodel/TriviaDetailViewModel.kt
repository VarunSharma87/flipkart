package com.example.pottertrivia.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pottertrivia.data.repository.BookRepository
import com.example.pottertrivia.data.repository.CharacterRepository
import com.example.pottertrivia.data.repository.HouseRepository
import com.example.pottertrivia.data.repository.SpellRepository
import com.example.pottertrivia.ui.model.TriviaDetail
import com.example.pottertrivia.ui.model.TriviaDetailUiState
import dagger.Lazy
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TriviaDetailViewModel @Inject constructor() : ViewModel() {

    @Inject
    lateinit var bookRepo: Lazy<BookRepository>

    @Inject
    lateinit var houseRepo: Lazy<HouseRepository>

    @Inject
    lateinit var spellRepo: Lazy<SpellRepository>

    @Inject
    lateinit var characterRepo: Lazy<CharacterRepository>

    private val _triviaDetail = MutableLiveData<TriviaDetailUiState>()
    val triviaDetail: LiveData<TriviaDetailUiState> = _triviaDetail

    fun fetchBookDetails(title: String) {
        viewModelScope.launch {
            val result = bookRepo.get().getBookDetails(title)
            _triviaDetail.value = TriviaDetailUiState(
                TriviaDetail(
                    titleBarText = result.title,
                    title = result.releaseDate,
                    cover = result.cover,
                    description = result.description
                )
            )
        }
    }

    fun fetchSpellDetails(spell: String) {
        viewModelScope.launch {
            val result = spellRepo.get().getSpellDetails(spell)
            _triviaDetail.value =
                TriviaDetailUiState(
                    TriviaDetail(
                        titleBarText = result.spell,
                        title = result.spell,
                        description = result.use
                    )
                )
        }
    }

    fun fetchCharacterDetails(fullName: String) {
        viewModelScope.launch {
            val result = characterRepo.get().getCharacterDetails(fullName)
            _triviaDetail.value = TriviaDetailUiState(
                TriviaDetail(
                    titleBarText = result.nickname,
                    title = result.birthdate,
                    cover = result.image,
                    description = result.fullName
                )
            )
        }
    }

    fun fetchHouseDetails(house: String) {
        viewModelScope.launch {
            val result = houseRepo.get().getHouseDetails(house)
            _triviaDetail.value = TriviaDetailUiState(
                TriviaDetail(
                    titleBarText = result.house,
                    title = result.house,
                    description = result.founder
                )
            )
        }
    }
}