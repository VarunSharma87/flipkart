package com.example.pottertrivia.domain.model

data class House(
    val founder: String,
    val house: String
)
