package com.example.pottertrivia.data.remote.model

import com.example.pottertrivia.data.local.entity.HousesEntity
import com.example.pottertrivia.domain.model.House

data class HouseDto(
    val animal: String,
    val colors: List<String>,
    val emoji: String,
    val founder: String,
    val house: String,
    val index: Int
)

fun HouseDto.toEntityModel() = HousesEntity(house, index, animal, colors, emoji, founder)

fun HouseDto.toDomainModel() = House(
    founder,
    house
)