package com.example.pottertrivia.domain.model

sealed class TriviaSearchResult {
    data class Character(
        val birthdate: String,
        val children: List<String>,
        val fullName: String,
        val hogwartsHouse: String,
        val image: String,
        val index: Int,
        val interpretedBy: String,
        val nickname: String
    ) : TriviaSearchResult()

    data class Book(
        val cover: String,
        val description: String,
        val index: Int,
        val number: Int,
        val originalTitle: String,
        val pages: Int,
        val releaseDate: String,
        val title: String
    ) : TriviaSearchResult()

    data class House(
        val animal: String,
        val colors: List<String>,
        val emoji: String,
        val founder: String,
        val house: String,
        val index: Int
    ) : TriviaSearchResult()

    data class Spell(
        val index: Int,
        val spell: String,
        val use: String
    ) : TriviaSearchResult()

    data class Header(val title: String) : TriviaSearchResult()
}