package com.example.pottertrivia.data.repository

import com.example.pottertrivia.data.local.dao.HousesDao
import com.example.pottertrivia.data.local.entity.toDomainModel
import com.example.pottertrivia.data.remote.TriviaRemoteSource
import com.example.pottertrivia.data.remote.model.toDomainModel
import com.example.pottertrivia.data.remote.model.toEntityModel
import com.example.pottertrivia.domain.model.House
import javax.inject.Inject

class HouseRepositoryImpl @Inject constructor(
    private val localSource: HousesDao,
    private val remoteSource: TriviaRemoteSource
) : HouseRepository {
    override suspend fun getHouses(
        searchQuery: String,
        networkAvailable: Boolean
    ): List<House> {
        return if (networkAvailable) {
            val result = remoteSource.fetchHouses(searchQuery)
            localSource.insertAll(result.map { it.toEntityModel() })
            result.map { it.toDomainModel() }
        } else {
            localSource.getMatchingHouses(searchQuery).map { it.toDomainModel() }
        }
    }

    override suspend fun getHouseDetails(
        house: String,
    ): House {
        return localSource.getHouseDetails(house).toDomainModel()
    }
}