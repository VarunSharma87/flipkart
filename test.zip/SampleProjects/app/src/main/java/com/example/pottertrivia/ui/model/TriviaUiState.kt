package com.example.pottertrivia.ui.model

import com.example.pottertrivia.domain.model.Spell

data class TriviaUiState(
    val randomSpell: Spell?,
    val searchResult: List<TriviaItem>? = null
)