package com.example.pottertrivia.ui.model

import com.example.pottertrivia.domain.model.TriviaSearchResult

data class TriviaUiState(
    val characters: List<TriviaSearchResult>
)
