package com.example.pottertrivia.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pottertrivia.data.repository.TriviaRepository
import com.example.pottertrivia.domain.model.TriviaSearchResult
import kotlinx.coroutines.launch
import javax.inject.Inject

class BookDetailViewModel : ViewModel() {

    @Inject
    lateinit var triviaRepo: TriviaRepository

    private val _bookDetail = MutableLiveData<TriviaSearchResult.Book>()
    val bookDetail: LiveData<TriviaSearchResult.Book> = _bookDetail

    fun fetchBookDetails(number: Int) {
        viewModelScope.launch {
            val result = triviaRepo.getBook(number)
            _bookDetail.value = result
        }
    }
}