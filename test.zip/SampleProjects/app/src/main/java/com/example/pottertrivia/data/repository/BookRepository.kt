package com.example.pottertrivia.data.repository

import com.example.pottertrivia.domain.model.Book

interface BookRepository {
    suspend fun getBooks(
        searchQuery: String,
        isNetworkAvailable: Boolean
    ): List<Book>

    suspend fun getBookDetails(title: String): Book
}