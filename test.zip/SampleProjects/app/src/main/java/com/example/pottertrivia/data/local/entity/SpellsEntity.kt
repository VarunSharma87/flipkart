package com.example.pottertrivia.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.pottertrivia.domain.model.TriviaSearchResult

@Entity(tableName = "spells")
data class SpellsEntity(
    @PrimaryKey
    @ColumnInfo("index")
    val index: Int,
    @ColumnInfo("spell")
    val spell: String,
    @ColumnInfo("use")
    val use: String
)

fun SpellsEntity.toDomainModel() = TriviaSearchResult.Spell(index, spell, use)