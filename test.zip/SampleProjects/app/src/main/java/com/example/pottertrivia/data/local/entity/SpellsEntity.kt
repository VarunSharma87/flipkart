package com.example.pottertrivia.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.pottertrivia.domain.model.Spell

@Entity(tableName = "spells")
data class SpellsEntity(
    @PrimaryKey
    @ColumnInfo("spell")
    val spell: String,
    @ColumnInfo("index")
    val index: Int,
    @ColumnInfo("use")
    val use: String
)

fun SpellsEntity.toDomainModel() = Spell(index, spell, use)