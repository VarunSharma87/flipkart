package com.example.pottertrivia.di

import com.example.pottertrivia.data.local.PotterDatabase
import com.example.pottertrivia.data.local.dao.BooksDao
import com.example.pottertrivia.data.local.dao.CharactersDao
import com.example.pottertrivia.data.local.dao.HousesDao
import com.example.pottertrivia.data.local.dao.SpellsDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object DaosModule {

    @Provides
    fun providesCharactersDao(database: PotterDatabase): CharactersDao {
        return database.charactersDao()
    }

    @Provides
    fun providesBooksDao(database: PotterDatabase): BooksDao {
        return database.booksDao()
    }

    @Provides
    fun providesSpellsDao(database: PotterDatabase): SpellsDao {
        return database.spellsDao()
    }

    @Provides
    fun providesHousesDao(database: PotterDatabase): HousesDao {
        return database.housesDao()
    }
}