package com.example.pottertrivia.ui.viewholder

import android.R.drawable
import android.graphics.Color
import android.provider.CalendarContract.Colors
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.pottertrivia.domain.model.TriviaSearchResult
import com.example.pottertriviaapp.R
import com.example.pottertriviaapp.databinding.TriviaListItemBinding

class TriviaSearchResultViewHolder(private val binding: TriviaListItemBinding) :
    ViewHolder(binding.root) {

    fun bind(searchResult: TriviaSearchResult, clickListener: ((TriviaSearchResult) -> Unit)?) {
        binding.itemParent.setBackgroundColor(Color.TRANSPARENT)
        when (searchResult) {
            is TriviaSearchResult.Character -> binding.triviaText.text = searchResult.fullName
            is TriviaSearchResult.Book ->{
                binding.triviaText.text = searchResult.title
                binding.triviaText.setOnClickListener {
                    clickListener?.let { it(searchResult) }
                }
            }
            is TriviaSearchResult.House -> binding.triviaText.text = searchResult.house
            is TriviaSearchResult.Spell -> binding.triviaText.text = searchResult.spell
            is TriviaSearchResult.Header -> {
                binding.triviaText.text = searchResult.title
                binding.itemParent.setBackgroundColor(Color.GRAY)
            }
        }
    }
}