package com.example.pottertrivia.data.repository

import com.example.pottertrivia.data.local.dao.CharactersDao
import com.example.pottertrivia.data.local.entity.toDomainModel
import com.example.pottertrivia.data.remote.TriviaRemoteSource
import com.example.pottertrivia.data.remote.model.toDomainModel
import com.example.pottertrivia.data.remote.model.toEntityModel
import com.example.pottertrivia.domain.model.TriviaSearchResult
import javax.inject.Inject

class BooksRepository @Inject constructor(
private val charactersDao: CharactersDao,
private val remoteSource: TriviaRemoteSource,
) {

    suspend fun getBooks(
        searchQuery: String,
        isNetworkAvailable: Boolean
    ): List<TriviaSearchResult.Character> {
        return if (isNetworkAvailable) {
            val result = remoteSource.fetchCharacters(searchQuery)
            charactersDao.insertAll(result.map { it.toEntityModel() })
            result.map { it.toDomainModel() }
        } else {
            charactersDao.getMatchingCharacters(searchQuery).map { it.toDomainModel() }
        }
    }
}