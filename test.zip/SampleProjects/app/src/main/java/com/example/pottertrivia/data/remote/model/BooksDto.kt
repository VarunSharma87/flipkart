package com.example.pottertrivia.data.remote.model

import com.example.pottertrivia.data.local.entity.BooksEntity
import com.example.pottertrivia.domain.model.TriviaSearchResult

data class BooksDto(
    val cover: String,
    val description: String,
    val index: Int,
    val number: Int,
    val originalTitle: String,
    val pages: Int,
    val releaseDate: String,
    val title: String
)

fun BooksDto.toEntityModel() = BooksEntity(
    number,
    cover,
    description,
    index,
    originalTitle,
    pages,
    releaseDate,
    title
)

fun BooksDto.toDomainModel() = TriviaSearchResult.Book(
    cover,
    description,
    index,
    number,
    originalTitle,
    pages,
    releaseDate,
    title
)